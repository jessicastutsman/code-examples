# Changelog

    1.0.7
    # Fixed blog layout on mobile devices
    # Fixed template widgets media 'auto' settings

    1.0.6
    # Fixed theme specific widget shown as core widget

    1.0.5
    # Fixed empty link on image in layouts/article.php
    + Added loading of media/jui/less/modals.joomla.less to /less/bootstrap.less

    1.0.4
    + Added module/widget position for modal
    # Fixed breakpoint issue for navbar

    1.0.3
    # Fixed sidebar alignment, left/right are replaced by display first option
    # Updated to Warp 7.3.9, sticky navigation behavior is now working

    1.0.2
    # Fixed link anchor for images in WordPress _post.php for top aligned images
    + Added link anchors for images in Joomla article.php

    1.0.1
    - Removed fonts folder
    + Added missing customizer variables for font selection at Typography
    + Added link anchor to WordPress _post.php images

    1.0.0
    + Initial Release


    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
