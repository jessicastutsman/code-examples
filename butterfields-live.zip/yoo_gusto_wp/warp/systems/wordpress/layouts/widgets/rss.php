<?php echo $widget->content; ?>

<p>
    <a class="uk-button" href="<?php echo $widget->params['url']; ?>" target="_blank"><?php _e('Read feed'); ?></a>
</p>
