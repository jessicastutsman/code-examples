# Changelog

    1.0.4
    # -> Fixed grid_avanti dynamic grid overlapping images
    + -> Added grid_avanti dynamic grid tag filter list

    1.0.3
    ^ -> Changed base-font-families from variables to font families for better customization

    1.0.2
    + -> Added RTL support for slidenav component arrows
    # -> Fixed Hide page title option for WordPress
    # -> Fixed Avanti Grid Widget content and title truncate options
    # -> Fixed left/right image display for WordPress single posts
    ! -> Text truncate now works correctly, Widgetkit 2.5.3 is required!

    1.0.1
    # -> Added missing font path for custom theme font

    1.0.0
    + Initial Release


    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
